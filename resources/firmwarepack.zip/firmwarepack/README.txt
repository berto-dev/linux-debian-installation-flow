These files help Debian Installer detect helpful firmware packages (via hw-detect).
you can and copy n paste all firmaware in new iso inside firmaware/deb11
